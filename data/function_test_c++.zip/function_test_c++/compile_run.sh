# Modify your compilation command here
#/*----------------------------------------------------------*/
g++ -std=c++17 main.cpp -o main.o
./main.o
#/*----------------------------------------------------------*/
#// Copyright © 2023 by Timur Uzakov (testogram.eu)
