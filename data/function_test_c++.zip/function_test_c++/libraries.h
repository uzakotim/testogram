// Include all necessary libraries here
/*----------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <math.h>
#include <vector>
/*----------------------------------------------------------*/
// Copyright © 2023 by Timur Uzakov (testogram.eu)


