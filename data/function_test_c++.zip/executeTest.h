// Function to write commands to produce tests
/* ----------------------------------------------------- */
#include "handleTest.h"
void execute_tests()
{
    // handleTest(testNumber, input, reference)
    handleTest(1,1, "1");    
}
/* ----------------------------------------------------- */
